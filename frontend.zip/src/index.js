import React from 'react';
import ReactDOM from 'react-dom/client';
import Reporte1 from './reporte1';
import Reporte2 from './reporte2';
import Reporte3 from './reporte3';
import './index.css';

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <>
    <Reporte1 />
    <Reporte2 />
    <Reporte3 />
    <h1>hola</h1>
  </>
);
