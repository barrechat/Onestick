import React,{useEffect,useState} from "react";

const TableData = React.createContext({
    data: [], fetchData: () => {}
  })
export default function Reporte2(){
    
    const [data,setData] = useState([])
    const fetchData = async () =>{
        const response = await fetch("http://localhost:8000/ranking").then(response =>response.json())
        setData(response.data)
    }   
    useEffect(()=>{fetchData()},[])
    return(
    <div class="body">
        <div class="header">
        <button onClick={fetch("http://localhost:8000/download/customer_ranking.csv")}>Descarga</button>
        <label>Selecciona un archivo csv para añadir:</label>
        <input type ="file" accept=".csv">Selecciona archivo</input>
        </div>
        <table>
            <thead>
                <th>ID</th>
                <th>NOMBRE</th>
                <th>APELLIDO</th>
                <th>TOTAL</th>
            </thead>
            <tbody>
                {data.map((pedido,index)=>{
                    return(
                        <tr key = {pedido.id}>
                            <td>{pedido.id}</td>
                            <td>{pedido.name}</td>
                            <td>{pedido.lastname}</td>
                            <td>{pedido.total}</td>
                        </tr>
                    )
                })}
            </tbody>
        </table>
    </div>)
}