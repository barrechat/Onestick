import React,{useEffect,useState} from "react";

const TableData = React.createContext({
    data: [], fetchData: () => {}
  })

export default function Reporte1(){

    const [data,setData] = useState([])
    const fetchData = async () =>{
        const response = await fetch("http://127.0.0.1:8000/total").then(response =>response.json())
        setData(response.data)
    }   
    useEffect(()=>{fetchData()},[])
    
    return(
    <div class="body">
        <div class="header">
        <button onClick={fetch("http://127.0.0.1:8000/download/order_prices.csv")}>Descarga</button>
        <label>Selecciona un archivo csv para añadir:</label>
        <input type ="file" accept=".csv">Selecciona archivo</input>
        </div>
        <table>
            <thead>
                <th>ID</th>
                <th>TOTAL</th>
            </thead>
            <tbody>
                {data.map((pedido,index)=>{
                    return(
                        <tr key = {pedido.id}>
                            <td>{pedido.id}</td>
                            <td>{pedido.total}</td>
                        </tr>
                    )
                })}
            </tbody>
        </table>
    </div>)
}